package main;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class BankThread extends Thread {
	private Socket sock;
	private ObjectOutputStream out;
	private ObjectInputStream in;
	private static String atmID;
	private static String nonce;
	private static Cipher ciph;
	private static String sharedKey = "BankKey817";
	private static SecretKey sec;
	private static SecretKey tempSec;
	private static SecretKey masterSec;
	private static byte[] encrypted;
	private static byte[] decrypted;
	private static byte[] encryptedIn;
	private static Timestamp ts = new Timestamp(System.currentTimeMillis());
	private static String masterString;
	
	private static SecretKey encryptionKey;
	private static String macKey;
	private static clientFile client;
	public BankThread (Socket s) {
		this.sock = s;
		try {
			out = new ObjectOutputStream(sock.getOutputStream());
			in = new ObjectInputStream(sock.getInputStream());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private static void generateNonce () {
		SecureRandom n = new SecureRandom();
		byte[] nBytes = new byte[5];
		n.nextBytes(nBytes);
		nonce = Base64.getEncoder().encodeToString(nBytes);
	}
	
	private static SecretKey generateSecret(String key) {
		try { 
			SecretKeyFactory fact = SecretKeyFactory.getInstance("DES");
			byte[] b = key.getBytes();
			return fact.generateSecret(new DESKeySpec(b));
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public static void encodeDES (String message, SecretKey s) {
		try {
			ciph = Cipher.getInstance("DES/ECB/PKCS5Padding");
			ciph.init(Cipher.ENCRYPT_MODE, s);
			encrypted = ciph.doFinal(message.getBytes());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void encodeDES (byte[] message, SecretKey s) {
		try {
			ciph = Cipher.getInstance("DES/ECB/PKCS5Padding");
			ciph.init(Cipher.ENCRYPT_MODE, s);
			encrypted = ciph.doFinal(message);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void decodeDES (byte[] message, SecretKey s) {
		try {
			ciph = Cipher.getInstance("DES/ECB/PKCS5Padding");
			ciph.init(Cipher.DECRYPT_MODE, s);
			decrypted = ciph.doFinal(message);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static void masterGenerate (String message) {
		try {
			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			byte[] b = digest.digest(message.getBytes());
			StringBuilder hexString = new StringBuilder(2 * b.length);
		    for (int i = 0; i < b.length; i++) {
		        String hex = Integer.toHexString(0xff & b[i]);
		        if(hex.length() == 1) {
		            hexString.append('0');
		        }
		        hexString.append(hex);
		    }
		    masterString = hexString.toString();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static void addToLog (String message) {
		try {
			LocalDateTime ldt = Instant.ofEpochMilli(ts.getTime()).atZone(ZoneId.systemDefault()).toLocalDateTime();
			String m = message + "|" + ldt;
			encodeDES(m, sec);
			String s = Base64.getEncoder().encodeToString(encrypted);
			FileWriter file = new FileWriter("latest.log", true);
			BufferedWriter write = new BufferedWriter(file);
			write.write(s);
			write.newLine();
			write.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static String hmac(String data, String key){
		try {
		    SecretKeySpec secretKeySpec = new SecretKeySpec(key.getBytes(), "HmacSHA256");
		    Mac mac = Mac.getInstance("HmacSHA256");
		    mac.init(secretKeySpec);
		    byte[] b = mac.doFinal(data.getBytes());
		    String r = "";
		    for (byte i : b) {
		    	r += String.format("%02X", i);
		    }
		    return r;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	private static boolean verifyMac(String[] arr) {
		if (arr[arr.length - 1].compareTo(hmac("macKey", masterString)) == 0) {
			if (new Timestamp(System.currentTimeMillis()).getTime() - Long.parseLong(arr[arr.length - 2]) < 1500)
			return true;
		}
		return false;
	}
	
	@Override
	public void run() {
		try {
			System.out.println("Connected: " + sock.getRemoteSocketAddress());
			generateNonce();
			sec = generateSecret(sharedKey);
			encryptedIn = (byte[])in.readObject();
			decodeDES(encryptedIn, sec);
			String message = new String(decrypted);
			String[] arr = message.split("\\|");
			String nonceA = arr[0];
			if (Long.parseLong(arr[1]) - new Timestamp(System.currentTimeMillis()).getTime() > 20) {
				System.out.println("Timestamp invalid, closing connection");
				sock.close();
				return;
			}
			atmID = arr[2];
			tempSec = generateSecret(nonce);
			message = arr[0] + "|" + nonce + "|" + Long.toString(ts.getTime());
			encodeDES(message, sec);
			out.writeObject(encrypted);
			encodeDES(tempSec.getEncoded(), sec);
			out.writeObject(encrypted);
			encryptedIn = (byte[]) in.readObject();
			decodeDES(encryptedIn, tempSec);
			arr = new String(decrypted).split("\\|");
			if (arr[0].compareTo(nonce) != 0 || new Timestamp(System.currentTimeMillis()).getTime() - Long.parseLong(arr[1]) > 20) {
				System.out.println("Message invalid, closing connection");
				sock.close();
				return;
			}
			masterGenerate(nonceA + nonce);
			masterSec = generateSecret(masterString);
			encryptedIn = (byte[]) in.readObject();
			decodeDES(encryptedIn, masterSec);
			if (masterString.compareTo(new String(decrypted)) != 0){
				System.out.println("Master Secret Invalid, closing connection");
				sock.close();
				return;
			}
			encodeDES(masterString, masterSec);
			out.writeObject(encrypted);
			
			encryptionKey = generateSecret(hmac("encryption", masterString));
			macKey = hmac("macKey", masterString);
			boolean loggedIn = false;
			while (loggedIn == false) {
				encryptedIn = (byte[]) in.readObject();
				decodeDES(encryptedIn, encryptionKey);
				String[] ar = new String(decrypted).split("\\|");
				if (verifyMac(ar) == false) {
					System.out.println("Invalid message detected, closing connection");
					sock.close();
					return;
				}
				for (clientFile c : BankServer.getClients()) {
					String u = c.getLogin();
					if (u.compareTo(ar[0] + "|" + ar[1]) == 0) {
						message = "Login Successful" + "|" + new Timestamp(System.currentTimeMillis()).getTime() + "|" + macKey;
						loggedIn = true;
						client = c;
						encodeDES(message, encryptionKey);
						out.writeObject(encrypted);
						break;
					}
				}
				if (loggedIn != true) {
					message = "Invalid Login" + "|" + new Timestamp(System.currentTimeMillis()).getTime() + "|" + macKey;
					encodeDES(message, encryptionKey);
					out.writeObject(encrypted);
				}
			}
			
			while (true) {
				System.out.println("in");
				encryptedIn = (byte[]) in.readObject();
				decodeDES(encryptedIn, encryptionKey);
				String[] a = new String(decrypted).split("\\|");
				if (verifyMac(a) == false) {
					System.out.println("Invalid message detected, closing connection");
					sock.close();
					return;
				}
				String m;
				switch (Integer.parseInt(a[0])) {
					case 1:
						client.depositMoney(Double.parseDouble(a[1]));
						addToLog(client.getLogin().split("\\|")[0] + "|" + "Deposit");
						break;
					case 2:
						client.withdrawMoney(Double.parseDouble(a[1]));
						addToLog(client.getLogin().split("\\|")[0] + "|" + "Withdraw");
						break;
					case 3:
						m = Double.toString(client.getBalance()) + "|" + new Timestamp(System.currentTimeMillis()).getTime() + "|"+ macKey;
						System.out.println(m);
						encodeDES(m, encryptionKey);
						out.writeObject(encrypted);
						addToLog(client.getLogin().split("\\|")[0] + "|" + "CheckBalance");
						break;
					case 4:
						sock.close();
						return;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
